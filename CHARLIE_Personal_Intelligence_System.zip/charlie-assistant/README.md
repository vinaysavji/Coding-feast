# CHARLIE — Personal Intelligence System

**Always aware. Always ready.** A modular, responsive personal assistant starter built with HTML, CSS, vanilla JavaScript, Node.js, Express and optional Supabase + OpenAI integrations.

## Current implementation status

| Feature | Status |
|---|---|
| Responsive dashboard and navigation | Implemented |
| Notes CRUD + search | Implemented |
| Tasks CRUD, priority, due date, completion filters | Implemented |
| Memory CRUD + consent prompt + clear all | Implemented |
| Chat UI, timestamps, new conversation, typing state | Implemented |
| Clearly labelled simulated chat when no API key exists | Implemented |
| Server-side OpenAI Chat Completions integration | Implemented; requires key |
| Supabase-backed data access and JWT verification | Implemented; requires project configuration and SQL |
| Local JSON demo persistence | Implemented; local development only |
| Document upload + metadata listing/deletion | Partial: local file upload; metadata CRUD |
| Supabase Storage upload | Not implemented |
| Sign-up/sign-in UI | Not implemented |
| Persistent conversation history | Not implemented |
| Browser text-to-speech test | Implemented where supported |
| Speech-to-text chat dictation | Not implemented |
| Multimodal image analysis | Not implemented |
| RAG / document summarization | Not implemented |
| Workflow execution engine / activity feed | Not implemented |
| Persistent user settings | UI foundation only |

This project intentionally labels unavailable integrations rather than simulating success.

## Requirements

- Node.js 18 or later
- npm
- Optional Supabase project
- Optional OpenAI API key

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

Open http://localhost:3000.

With empty Supabase and OpenAI values, the app runs in **LOCAL DEMO MODE**. Notes, tasks and memories persist in `backend/data/demo-store.json`; this mode is not suitable for multi-user or production deployment. Demo records are not protected by account authentication. Do not expose the demo server publicly.

## Enable real AI

Set `OPENAI_API_KEY` in `.env` on the server. Optionally set `OPENAI_MODEL`. Restart the server. The browser never receives the provider key. The app uses the OpenAI Chat Completions endpoint from the backend. Usage is subject to your provider account and billing.

## Enable Supabase authentication and database

1. Create a Supabase project.
2. Copy Project URL and anon/public key into `.env` as `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
3. Run `database/schema.sql` in the Supabase SQL editor.
4. Restart the server.

When Supabase is configured, API data routes require a valid Supabase access token in the `Authorization: Bearer <token>` header. RLS policies restrict rows to `auth.uid()`. **The included frontend does not yet implement sign-in/sign-up or session acquisition**, so connect an authentication UI before normal browser use with Supabase enabled. Never use a service-role key in the browser or this app's public environment.

## Environment variables

See `.env.example`. All secrets belong in the server environment, never in frontend files or Git.

## API overview

All endpoints are prefixed with `/api`. Except `/api/health`, routes pass through authentication middleware. In local demo mode, a single local demo identity is used.

- `GET /health`
- `POST /chat` — `{ "messages": [{ "role": "user", "content": "Hello" }] }`
- `GET/POST /notes`; `PATCH/DELETE /notes/:id`
- `GET/POST /tasks`; `PATCH/DELETE /tasks/:id`
- `GET/POST /memories`; `PATCH/DELETE /memories/:id`; `DELETE /memories`
- `GET /documents`; `POST /documents/upload` (multipart field `file`); `DELETE /documents/:id`
- `GET /user_settings`; `POST /user_settings`; `PATCH/DELETE /user_settings/:id`

Validation errors return HTTP 400. Missing/invalid Supabase sessions return 401. Upload size limit defaults to 5 MB.

## Security notes before production

- Configure `APP_ORIGIN` and `CORS_ORIGINS` to exact production origins.
- Configure HTTPS at the hosting provider.
- Implement a complete sign-in/sign-up flow and session refresh before enabling Supabase mode for end users.
- Add Supabase Storage with private buckets and signed URLs before production document uploads. Current file uploads are stored on the server filesystem and metadata deletion does not delete uploaded bytes.
- The local JSON demo store is single-user development functionality and is not a production database.
- Add audit logging, automated tests, backup/restore, monitoring and stricter per-route rate limits before launch.
- Add malware scanning and content validation before accepting user documents publicly.
- Do not store secrets in source control. Rotate any key accidentally committed.

## Deployment

Deploy to a Node.js host that supports persistent environment variables and, if using local demo uploads, persistent disk. Set `NODE_ENV=production`, `PORT`, `APP_ORIGIN`, `CORS_ORIGINS`, Supabase credentials and optional AI key in the host's secret manager. Run `npm install` and `npm start`. Use Supabase for production data; do not use local demo JSON storage in a multi-user production deployment.

## Testing checklist

- [ ] `npm install` completes
- [ ] `npm run check` passes
- [ ] `/api/health` reports expected modes
- [ ] Dashboard and sidebar navigation work
- [ ] Chat demo is labelled and never claims to be live AI
- [ ] Notes create/edit/delete/search and persist after refresh
- [ ] Tasks create/edit/delete/complete/filter
- [ ] Memory add requires consent; delete and clear all work
- [ ] Theme toggle works
- [ ] Upload accepts supported types and enforces size limit
- [ ] Supabase JWT verification and RLS tested with two separate accounts
- [ ] Live AI tested with server-side key
- [ ] Mobile layout and keyboard navigation tested on target devices

## Known limitations

This is a runnable foundation, not a fully production-certified assistant. Authentication screens, Supabase Storage, persistent chat history, complete voice input, vision, RAG, real workflow automation, settings persistence and automated integration tests remain future work. No camera or microphone is activated automatically.
