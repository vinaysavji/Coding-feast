const env = require("../config/env");
const { authClient } = require("../config/supabase");

async function requireUser(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!env.supabaseEnabled) {
    // Local demo mode stores data in a local JSON file and is not an authenticated account.
    req.user = { id: "local-demo-user", demo: true };
    return next();
  }
  if (!token) return res.status(401).json({ error: "Sign in to access your private workspace." });
  try {
    const { data, error } = await authClient.auth.getUser(token);
    if (error || !data.user) return res.status(401).json({ error: "Your session is invalid or expired." });
    req.user = { id: data.user.id, email: data.user.email, demo: false };
    next();
  } catch {
    res.status(401).json({ error: "Unable to verify your session." });
  }
}
module.exports = { requireUser };
