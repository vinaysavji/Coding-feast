const express = require("express");
const multer = require("multer");
const path = require("path");
const { z } = require("zod");
const { requireUser } = require("../middleware/auth");
const data = require("../services/dataService");
const ai = require("../services/aiService");
const env = require("../config/env");

const router = express.Router();
router.use(requireUser);
router.use((req, _res, next) => { req.token = (req.headers.authorization || "").replace(/^Bearer /, ""); next(); });

const schemas = {
  notes: z.object({ title: z.string().trim().min(1).max(120), content: z.string().max(20000).default("") }),
  tasks: z.object({ title: z.string().trim().min(1).max(180), description: z.string().max(2000).optional().default(""), priority: z.enum(["low","medium","high"]).default("medium"), due_date: z.string().nullable().optional(), completed: z.boolean().default(false) }),
  memories: z.object({ content: z.string().trim().min(1).max(1000), category: z.string().max(60).default("Preference"), consent: z.literal(true) }),
  user_settings: z.object({ theme: z.enum(["dark","light"]).optional(), assistant_name: z.string().max(40).optional(), personality: z.string().max(1000).optional(), notifications: z.boolean().optional() })
};
const tables = ["notes","tasks","memories","documents","user_settings","conversations","messages","activity_logs"];

router.get("/health", (_req,res) => res.json({ status:"ok", mode: env.supabaseEnabled ? "supabase" : "demo", ai: env.aiEnabled ? "live" : "demo", timestamp: new Date().toISOString() }));

router.post("/chat", async (req,res,next) => {
  try {
    const body = z.object({ messages: z.array(z.object({ role: z.enum(["user","assistant"]), content: z.string().max(8000) })).min(1).max(30) }).parse(req.body);
    const result = await ai.reply(body.messages);
    res.json(result);
  } catch(e) { next(e); }
});

for (const table of ["notes","tasks","memories","documents","user_settings"]) {
  router.get(`/${table}`, async (req,res,next) => { try { res.json(await data.list(table,req)); } catch(e){next(e);} });
  if (schemas[table]) {
    router.post(`/${table}`, async (req,res,next) => { try { const payload=schemas[table].parse(req.body); res.status(201).json(await data.create(table,req,payload)); } catch(e){next(e);} });
    router.patch(`/${table}/:id`, async (req,res,next) => { try { const payload=schemas[table].partial().parse(req.body); res.json(await data.update(table,req,req.params.id,payload)); } catch(e){next(e);} });
  }
  router.delete(`/${table}/:id`, async (req,res,next) => { try { const ok=await data.remove(table,req,req.params.id); res.status(ok?204:404).end(); } catch(e){next(e);} });
}
router.delete("/memories", async (req,res,next) => { try { const rows=await data.list("memories",req); await Promise.all(rows.map(r=>data.remove("memories",req,r.id))); res.status(204).end(); } catch(e){next(e);} });

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req,_file,cb) => { const fs=require("fs"); const dir=path.join(__dirname,"..","uploads"); fs.mkdirSync(dir,{recursive:true}); cb(null,dir); },
    filename: (_req,file,cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname).toLowerCase()}`)
  }),
  limits: { fileSize: env.maxUploadMb * 1024 * 1024 },
  fileFilter: (_req,file,cb) => cb(null, ["application/pdf","text/plain","image/png","image/jpeg"].includes(file.mimetype))
});
router.post("/documents/upload", upload.single("file"), async (req,res,next) => {
  try {
    if (!req.file) return res.status(400).json({error:"Choose a supported PDF, TXT, PNG or JPG file."});
    const row = await data.create("documents",req,{ name:req.file.originalname.slice(0,180), mime_type:req.file.mimetype, size:req.file.size, storage_path:req.file.filename, processing_status:"Stored — analysis not enabled" });
    res.status(201).json(row);
  } catch(e){next(e);}
});

module.exports = router;
