const env = require("../config/env");
const { userClient } = require("../config/supabase");
const demo = require("./demoStore");

async function list(table, req) {
  if (req.user.demo) return demo.list(table, req.user.id);
  const { data, error } = await userClient(req.token).from(table).select("*").order("updated_at", { ascending: false });
  if (error) throw error; return data || [];
}
async function create(table, req, payload) {
  if (req.user.demo) return demo.insert(table, req.user.id, payload);
  const { data, error } = await userClient(req.token).from(table).insert({ ...payload, user_id: req.user.id }).select().single();
  if (error) throw error; return data;
}
async function update(table, req, id, payload) {
  if (req.user.demo) return demo.update(table, req.user.id, id, payload);
  const { data, error } = await userClient(req.token).from(table).update(payload).eq("id", id).select().maybeSingle();
  if (error) throw error; return data;
}
async function remove(table, req, id) {
  if (req.user.demo) return demo.remove(table, req.user.id, id);
  const { data, error } = await userClient(req.token).from(table).delete().eq("id", id).select("id");
  if (error) throw error; return Boolean(data?.length);
}
module.exports = { list, create, update, remove };
