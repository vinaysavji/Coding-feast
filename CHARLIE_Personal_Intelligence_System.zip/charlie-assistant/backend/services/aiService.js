const env = require("../config/env");

const systemPrompt = `You are CHARLIE, a calm, intelligent and respectful personal intelligence assistant.
Be concise when possible and detailed when useful. Be honest about uncertainty.
Protect user privacy. Never claim to have performed actions you did not perform.
Ask for confirmation before consequential external actions.`;

async function reply(messages) {
  if (!env.aiEnabled) {
    const latest = messages.filter(m => m.role === "user").slice(-1)[0]?.content || "";
    return {
      mode: "demo",
      content: `CHARLIE Demo Mode: I received your message: “${latest.slice(0, 240)}”.\\n\\nConnect an LLM API key on the server to enable real AI responses. Your message has not been sent to an AI provider.`
    };
  }
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${env.openaiApiKey}` },
    body: JSON.stringify({
      model: env.openaiModel,
      messages: [{ role: "system", content: systemPrompt }, ...messages.slice(-20)],
      temperature: 0.6
    })
  });
  if (!response.ok) {
    const safeMessage = response.status === 401 ? "The AI provider rejected the configured API key." :
      response.status === 429 ? "The AI provider rate limit was reached. Try again shortly." :
      "The AI service is temporarily unavailable.";
    const err = new Error(safeMessage); err.status = response.status === 429 ? 429 : 502; throw err;
  }
  const result = await response.json();
  return { mode: "live", content: result.choices?.[0]?.message?.content || "I couldn't produce a response." };
}
module.exports = { reply };
