const fs = require("fs");
const path = require("path");
const dir = path.join(__dirname, "..", "data");
const file = path.join(dir, "demo-store.json");

function load() {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); }
  catch { return { notes: [], tasks: [], memories: [], conversations: [], messages: [], documents: [], activity_logs: [], user_settings: [] }; }
}
function save(data) {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2), { mode: 0o600 });
}
function list(table, userId) { return load()[table].filter(x => x.user_id === userId).sort((a,b) => (b.updated_at || b.created_at || "").localeCompare(a.updated_at || a.created_at || "")); }
function insert(table, userId, payload) {
  const db = load(); const now = new Date().toISOString();
  const row = { id: crypto.randomUUID(), user_id: userId, created_at: now, updated_at: now, ...payload };
  db[table].push(row); save(db); return row;
}
function update(table, userId, id, payload) {
  const db = load(); const i = db[table].findIndex(x => x.id === id && x.user_id === userId);
  if (i < 0) return null;
  db[table][i] = { ...db[table][i], ...payload, updated_at: new Date().toISOString() }; save(db); return db[table][i];
}
function remove(table, userId, id) {
  const db = load(); const before = db[table].length;
  db[table] = db[table].filter(x => !(x.id === id && x.user_id === userId));
  save(db); return before !== db[table].length;
}
const crypto = require("crypto");
module.exports = { list, insert, update, remove };
