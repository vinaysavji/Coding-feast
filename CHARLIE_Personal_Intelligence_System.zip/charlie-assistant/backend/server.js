const express = require("express");
const path = require("path");
const helmet = require("helmet");
const cors = require("cors");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const env = require("./config/env");
const api = require("./routes/api");

const app = express();
app.disable("x-powered-by");
app.use(helmet({ crossOriginResourcePolicy: { policy: "same-site" }, contentSecurityPolicy: false }));
app.use(cors({ origin(origin, cb) {
  if (!origin || env.corsOrigins.includes(origin) || env.nodeEnv !== "production") return cb(null,true);
  return cb(new Error("Origin not allowed"));
}}));
app.use(express.json({limit:"1mb"}));
app.use(morgan(env.nodeEnv === "production" ? "tiny" : "dev"));
app.use("/api", rateLimit({windowMs: 15*60*1000, limit: 120, standardHeaders:true, legacyHeaders:false}));
app.use("/api", api);
app.use(express.static(path.join(__dirname,"..","frontend")));
app.get("*", (_req,res) => res.sendFile(path.join(__dirname,"..","frontend","index.html")));

app.use((err,_req,res,_next) => {
  if (err.name === "ZodError") return res.status(400).json({error:"Please check the information you entered.", details:err.issues.map(x=>({field:x.path.join("."),message:x.message}))});
  if (err.code === "LIMIT_FILE_SIZE") return res.status(413).json({error:`File exceeds the ${env.maxUploadMb} MB limit.`});
  const status = err.status || 500;
  if (env.nodeEnv !== "production") console.error(err.message);
  res.status(status).json({error: status >= 500 ? (err.message || "Something went wrong.") : err.message});
});

app.listen(env.port, () => console.log(`CHARLIE running at http://localhost:${env.port} | ${env.supabaseEnabled ? "Supabase configured" : "LOCAL DEMO MODE"} | ${env.aiEnabled ? "Live AI configured" : "AI DEMO MODE"}`));
