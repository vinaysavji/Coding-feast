const { createClient } = require("@supabase/supabase-js");
const env = require("./env");

function userClient(accessToken) {
  if (!env.supabaseEnabled) return null;
  return createClient(env.supabaseUrl, env.supabaseAnonKey, {
    global: { headers: { Authorization: `Bearer ${accessToken}` } },
    auth: { persistSession: false, autoRefreshToken: false }
  });
}
const authClient = env.supabaseEnabled
  ? createClient(env.supabaseUrl, env.supabaseAnonKey, { auth: { persistSession: false } })
  : null;

module.exports = { userClient, authClient };
