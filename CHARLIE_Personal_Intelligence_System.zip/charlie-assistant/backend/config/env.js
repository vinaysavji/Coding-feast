require("dotenv").config();

const env = {
  port: Number(process.env.PORT || 3000),
  nodeEnv: process.env.NODE_ENV || "development",
  appOrigin: process.env.APP_ORIGIN || "http://localhost:3000",
  corsOrigins: (process.env.CORS_ORIGINS || "http://localhost:3000").split(",").map(x => x.trim()),
  supabaseUrl: process.env.SUPABASE_URL || "",
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY || "",
  openaiApiKey: process.env.OPENAI_API_KEY || "",
  openaiModel: process.env.OPENAI_MODEL || "gpt-4o-mini",
  maxUploadMb: Number(process.env.MAX_UPLOAD_MB || 5)
};
env.supabaseEnabled = Boolean(env.supabaseUrl && env.supabaseAnonKey);
env.aiEnabled = Boolean(env.openaiApiKey);
module.exports = env;
