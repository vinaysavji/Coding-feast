-- Run in the Supabase SQL editor. All user-owned tables enforce per-user RLS.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'New conversation',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid references public.conversations(id) on delete cascade,
  role text not null check (role in ('user','assistant','system')),
  content text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.memories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  content text not null check (char_length(content) <= 1000),
  category text not null default 'Preference',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  content text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text not null default '',
  priority text not null default 'medium' check (priority in ('low','medium','high')),
  due_date date,
  completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  mime_type text not null,
  size bigint not null default 0,
  storage_path text,
  processing_status text not null default 'Stored — analysis not enabled',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  event_type text not null,
  description text,
  created_at timestamptz not null default now()
);
create table if not exists public.user_settings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  theme text not null default 'dark' check (theme in ('dark','light')),
  assistant_name text not null default 'CHARLIE',
  personality text,
  notifications boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

do $$ declare t text; begin
  foreach t in array array['profiles','conversations','messages','memories','notes','tasks','documents','activity_logs','user_settings'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "user owns rows" on public.%I', t);
    if t = 'profiles' then
      execute 'create policy "user owns rows" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id)';
    else
      execute format('create policy "user owns rows" on public.%I for all using (auth.uid() = user_id) with check (auth.uid() = user_id)', t);
    end if;
  end loop;
end $$;

create index if not exists notes_user_updated_idx on public.notes(user_id, updated_at desc);
create index if not exists tasks_user_due_idx on public.tasks(user_id, due_date);
create index if not exists memories_user_idx on public.memories(user_id);
create index if not exists messages_conversation_idx on public.messages(conversation_id, created_at);
create index if not exists activity_user_idx on public.activity_logs(user_id, created_at desc);
