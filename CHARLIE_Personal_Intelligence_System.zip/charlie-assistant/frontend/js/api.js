const API = {
  token: null,
  async request(path, options = {}) {
    const headers = { ...(options.headers || {}) };
    if (this.token) headers.Authorization = `Bearer ${this.token}`;
    if (!(options.body instanceof FormData) && options.body) headers["Content-Type"] = "application/json";
    const response = await fetch(`/api${path}`, { ...options, headers });
    if (response.status === 204) return null;
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || `Request failed (${response.status})`);
    return body;
  },
  get(path){return this.request(path)},
  post(path, body){return this.request(path,{method:"POST",body:body instanceof FormData?body:JSON.stringify(body)})},
  patch(path, body){return this.request(path,{method:"PATCH",body:JSON.stringify(body)})},
  delete(path){return this.request(path,{method:"DELETE"})}
};
